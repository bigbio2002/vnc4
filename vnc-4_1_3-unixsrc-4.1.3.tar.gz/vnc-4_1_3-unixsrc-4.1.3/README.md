
VNC 4.1.3 Source Distribution for Unix platforms
==============================================

Copyright (C) 2002-2008 RealVNC Ltd.  All Rights Reserved.

This software is distributed under the GNU General Public Licence as
published by the Free Software Foundation.  See the file LICENCE.TXT
for the conditions under which this software is made available.  For
details on how to build this software, see the README file in the the
unix directory.
